Team Member: David Laguna
Team Name: LJD
Project Number: 3
Class Number: 335-05
Contents:2 folders, assets and HTML, a README.txt, and BigO.pdf
In assets there is a js file called proj3.js
External requirements: A web browser
Setup and installation: none
Features: Shows mergesort, quicksort, and selection sort side
by side.
Bugs: 

Tested in Google Chrome
==============================================================

How to handle proj3.html

1. Main file is proj3.html, a web page
2. Sibling folder is "assets"
3. Web page links to assets
4. Web page has basic title, header, and text
5. After body it loads draw-stuff.js from assets
6. Then runs some Javascript commands

How to run the web page:
7. Drag and drop the proj3.html file into a web browser