// JavaScript source code

//merge global vars
mrg_arr_size = 2;//starting size of each array compare
mrg_curr_array = 0;//curr array grouping we are on 
                   //counts both left and right array as 1 array 
mrg_l_end = 1;//end of l array for merge sort
mrg_r_end = 1;// end f r array for merge sort
mrg_l_chr = '';//l chr in l array
mrg_r_chr = '';//r char in r arr
mrg_string = "8A1593479085";//string to be sorted using merge sort
mrg_num_cmp_left = 0;//number of compares we did to left array
mrg_num_cmp_rgt = 0;//number of compares on right array
mrg_new_pass = true;//finished one pass of array
mrg_switch_flag = false;
mrg_num_passes = 0;//number of passes total for canvas
mrg_switch_val_l = [0, 0];//last 2 values we have compared. for canvas
mrg_switch_val_r = [0, 0];//last 2 values we have compared. for canvas
mrg_finished_flag = false;//is it complete
mrg_num_sub_arr = 0;// number of sub arrays we have compared on current pass
mrg_new_string = "";//next string that holds values
mrg_size_new_string = 0;

//quick global vars
qui_flag = false;//used to see whether we are coming from right or left
qui_finished_flag = false;//used to determine if we have finished the quick sort
qui_string = "8A1593479085";//input string
qui_p_char = 0;//current pivot value
qui_p_next_char = qui_string.length;//next pivot value or end of string
qui_left_char = qui_p_char + 1;//first char after pivot
qui_right_char = qui_p_next_char - 1;//first char before pivot
qui_arr_p = [false, false, false, false, false, false, false, false, false, false, false, false];//array to determine which values have pivots
qui_num_p = 1;//total number of pivots found
qui_num_p_used = 0;//number of pivots used on this pass
qui_num_passes = 0;//number of passes used. for canvas
qui_new_pass = true;//whether this step is a new pass. for canvas
qui_switch_val = 0;
qui_switch_p_flag = false;
qui_switch_c_flag = false;
qui_check = 20;//used for canvas

//selection global vars
sel_head = 0;
sel_next = sel_head + 1;
sel_tail = 0;
sel_string = "8A1593479085";
sel_finished_flag = false;


//classes for different compares
function mrg_curr_cmp(first, second, my_string)
{
    this.first = first;
    this.second = second;
    this.my_string = my_string;
}

function qui_curr_cmp(first, second, pivot, finished_flag, my_string) {
    this.first = first;
    this.second = second;
    this.pivot = pivot;
    this.finished_flag;
    this.my_string = my_string;
}

function sel_curr_cmp(first, second, finished_flag, my_string, found_val, switch_val)
{
    this.first = first;
    this.second = second;
    this.finished_flag;
    this.my_string = my_string;
    this.found_val = found_val;
    this.switch_val = switch_val;
}

//swap chars in str fun
function swapStr(str, first, second) {
    var arr = str.split('');
    var temp = arr[first];
    arr[first] = arr[second];
    arr[second] = temp;
    return arr.join('');
}

function swapStr2(str1, str2, first, second) {
    var arr1 = str1.split('');
    var arr2 = str2.split('');
    var temp = arr1[first];
    arr1[first] = arr2[second];
    arr2[second] = temp;
    return arr1.join('');
}

function mergesort()
{
    var curr_left_char = mrg_curr_array * mrg_arr_size + mrg_num_cmp_left;
    var curr_right_char = mrg_arr_size * mrg_curr_array + (mrg_arr_size / 2) + mrg_num_cmp_rgt;
    var l_end = mrg_l_end;
    var r_end = mrg_r_end;
    var my_str = mrg_string;
    var size = mrg_arr_size;
    var my_arr = mrg_curr_array;
    var mrg_class = new mrg_curr_cmp(curr_left_char, curr_right_char, mrg_string)
    mrg_switch_val_l[0] = mrg_switch_val_l[1];
    mrg_switch_val_r[0] = mrg_switch_val_r[1];
    mrg_switch_val_l[1] = curr_left_char;
    mrg_switch_val_r[1] = curr_right_char;
    mrg_l_chr = mrg_string.charAt(curr_left_char);
    mrg_r_chr = mrg_string.charAt(curr_right_char);

    //checks if we have gone off end of string and if we have push rest of chars onto string
    if (mrg_curr_array * mrg_arr_size + mrg_num_cmp_rgt + mrg_l_end >= mrg_string.length)
    {
        if (mrg_curr_array * mrg_arr_size + mrg_num_cmp_left < mrg_string.length)
        {
            while (mrg_num_cmp_left < mrg_l_end) {
                curr_left_char = mrg_curr_array * mrg_arr_size + mrg_num_cmp_left;
                mrg_l_chr = mrg_string.charAt(curr_left_char);
                mrg_new_string += mrg_l_chr;
                mrg_num_cmp_left++;
            }
        }
        mrg_arr_size = mrg_arr_size * 2;//double arr compare size
        mrg_curr_array = 0;
        mrg_l_end = mrg_l_end * 2;//double ends of l and r
        mrg_r_end = mrg_r_end * 2;
        mrg_new_pass = true;//say we have completed one pass
        mrg_num_passes++;
        mrg_num_sub_arr = 0;
        mrg_num_cmp_left = 0;//reset counter for left and right compares
        mrg_num_cmp_rgt = 0;

        for(var i = 0; i < mrg_new_string.length; i++)
        {
            mrg_string = swapStr2(mrg_string, mrg_new_string, i, i);//swaps new string into main string
        }
        mrg_new_string = "";
    }
    else
    {
        if (mrg_l_chr <= mrg_r_chr) {//check if left is smaller than right
            mrg_new_string += mrg_l_chr;//apend left onto new string
            mrg_num_cmp_left++;//increment l char
        }
        else {
            mrg_new_string += mrg_r_chr;//append r char onto new string
            mrg_class.my_string = mrg_string;//set mrg string to be old string
            mrg_num_cmp_rgt++;
            mrg_switch_flag = true;//falg for switching to true
        }

        if (mrg_num_cmp_left >= mrg_l_end) {//check if we have gone off left sub array
            while (mrg_num_cmp_rgt < mrg_r_end)//if there is a value left on right put it on the string
            {
                curr_right_char = mrg_arr_size * mrg_curr_array + (mrg_arr_size / 2) + mrg_num_cmp_rgt;
                mrg_r_chr = mrg_string.charAt(curr_right_char);
                mrg_new_string += mrg_r_chr;
                mrg_num_cmp_rgt++;
            }
            mrg_curr_array++;//increment which sub arr we are on
            mrg_num_cmp_left = 0;//reset the sub arr compare vals
            mrg_num_cmp_rgt = 0;

        }
        else if (mrg_num_cmp_rgt >= mrg_r_end) {//check if we have gone off thee right sub arr

            while (mrg_num_cmp_left < mrg_l_end) {//append all remaining left sub strings onto arr
                curr_left_char = mrg_curr_array * mrg_arr_size + mrg_num_cmp_left;
                mrg_l_chr = mrg_string.charAt(curr_left_char);
                mrg_new_string += mrg_l_chr;
                mrg_num_cmp_left++;
            }

            mrg_curr_array++;
            mrg_num_cmp_left = 0;
            mrg_num_cmp_rgt = 0;

        }
    }
    if (mrg_arr_size >= 32)
    {
        mrg_finished_flag = true;
    }
    return mrg_class;
}

//used to reset quicksort to default state
function qui_reset()
{
    qui_p_next_char = 0;//resets next pchar
    while (qui_arr_p[qui_p_next_char] == true && qui_p_next_char != qui_string.length) {//inc to next pivot in arr
        qui_p_next_char++;
        if (qui_arr_p[qui_p_next_char + 1] == true || qui_p_next_char == qui_string.length - 1) {//if size one sub arr then makes it a picot value
            qui_arr_p[qui_p_next_char] = true;
        }
    }
    qui_p_char = qui_p_next_char;//sets the p char to current pivot
    while (qui_arr_p[qui_p_next_char] == false) {//inc to next pivot in arr
        qui_p_next_char++;
    }
    qui_left_char = qui_p_char + 1;//reset left and right values in subarr
    qui_right_char = qui_p_next_char - 1;
    qui_num_p++;
    qui_num_p_used = 0;
    //qui_check = qui_check + 20;
    if(qui_p_char >= qui_string.length)//checks if pivot is off length of string
    {
        qui_finished_flag = true;
    }
    qui_num_passes++;
    qui_new_pass = true;
}

//gets next pivot value
function qui_check_next_p()
{
    if (qui_num_p <= qui_num_p_used)//resets if we have reached end of pass
    {
        qui_reset();
        
    }
    else
    {
        qui_p_next_char++;//inc to next pivot
        while (qui_arr_p[qui_p_next_char] == true && qui_p_next_char != qui_string.length)//checks to see if we reached end of string or if we have another pivot
        {
            qui_p_next_char++;
            if (qui_arr_p[qui_p_next_char + 1] == true || qui_p_next_char == qui_string.length - 1)
            {
                qui_arr_p[qui_p_next_char] = true;
            }
        }

        qui_p_char = qui_p_next_char;
        
        while (qui_arr_p[qui_p_next_char] == false && qui_p_next_char != qui_string.length) {
            qui_p_next_char++;
        }
        qui_left_char = qui_p_char + 1;
        qui_right_char = qui_p_next_char - 1;
        if(qui_left_char > qui_right_char)//if we have gone off the end of the string reset
        {
            qui_reset();
        }
    }
}

//quicksort step
function quicksort()
{
    var curr_p = qui_string.charAt(qui_p_char);//gets currnet pivot value
    var curr_l = qui_string.charAt(qui_left_char);//gets current left char
    var curr_r = qui_string.charAt(qui_right_char);//gets currrent right char
    var my_qui_p_char;
    var my_qui_class = new qui_curr_cmp(qui_left_char, qui_right_char, qui_p_char, false, qui_string);//creates a struct with those elements

    if(qui_flag == false)//checks if we havent found a smaller value on left
    {
        if(curr_l >= curr_p)//sees if value on left is smaller than pivot
        {
            qui_flag = true
        }
        else if (qui_left_char > qui_right_char) {//if we have gone off the end of left sub arr swap with pivot and reset
            qui_string = swapStr(qui_string, qui_p_char, qui_right_char);
            my_qui_class.my_string = qui_string;
            qui_arr_p[qui_right_char] = true;
            qui_num_p_used++;
            qui_check_next_p();
            qui_switch_p_flag = true;

        }
        else
        {
            qui_switch_val = qui_left_char;//used forr canvas
            qui_left_char++;//inc left char
        }
    }
    else {
        if(curr_r <= curr_p)//check if right value is less than pivot
        {
            if(qui_left_char > qui_right_char)//if we have crossed l and r chars then switch value with pivot
            {
                qui_string = swapStr(qui_string, qui_p_char, qui_right_char);
                my_qui_class.my_string = qui_string;
                qui_arr_p[qui_right_char] = true;
                qui_flag = false;
                qui_num_p_used++;
                qui_check_next_p();
                qui_switch_p_flag = true;

            }
            else if(qui_left_char == qui_right_char)//if l and r are equal then switch val with pivot
            {
                qui_string = swapStr(qui_string, qui_p_char, qui_right_char - 1);
                my_qui_class.my_string = qui_string;
                qui_arr_p[qui_right_char - 1] = true;
                qui_flag = false;
                qui_num_p_used++;
                qui_check_next_p();
                qui_switch_p_flag = true;
            }
            else//swap left and right char and reset
            {
                qui_string = swapStr(qui_string, qui_left_char, qui_right_char);
                my_qui_class.my_string = qui_string;
                qui_right_char--;
                qui_left_char++;
                qui_flag = false;
                qui_switch_c_flag = true;
            }
        }
        else//if curr r char is not less than pivot then decrement it
        {
            qui_switch_val = qui_right_char;
            qui_right_char--;
        }
        
    }
    my_qui_class.finished_flag = qui_finished_flag;
    return my_qui_class;
}

function selectionsort()
{
    var curr_head = sel_string.charAt(sel_head);
    var curr_next = sel_string.charAt(sel_next);
    var curr_tail = sel_string.charAt(sel_tail);
    var my_sel_class = new sel_curr_cmp(sel_tail, sel_next, false, sel_string, false, sel_tail);

    if(curr_tail > curr_next)//if tail is less then next char then switch
    {
        sel_string.switch_val = sel_tail;
        sel_tail = sel_next;
        my_sel_class.first = sel_tail;
    }
    else
    {
        my_sel_class.switch_val = sel_next;//used for canvas 
    }
    sel_next++;//inc to next com value
    my_sel_class.second = sel_next;
    if(sel_next >= sel_string.length)//check if we have gone off end of string and resets if we have
    {
        sel_string = swapStr(sel_string, sel_tail, sel_head);
        my_sel_class.my_string = sel_string;
        my_sel_class.found_val = true;
        sel_head++;
        sel_string.switch_val = sel_tail;
        sel_tail = sel_head;
        my_sel_class.first = sel_tail;
        sel_next = sel_head + 1;
        my_sel_class.second = sel_tail;
    }

    if(sel_head >= sel_string.length)//checks if head has gone off string and ends sort
    {
        sel_finished_flag = true;
    }
    return my_sel_class;
}

//-------------------------------------------------------------------
//only canvas manipulations below
//-------------------------------------------------------------------

function mrg_mng(context, mrg_class)
{
    if (mrg_new_pass == true)
    {
        mrg_new_pass = false;
        context.fillStyle = 'black';
        context.fillRect(8, 3 + (30 * (mrg_num_passes)), 190, 21);
        context.fillRect(8, 3 + (30 * (mrg_num_passes - 1)), 190, 21);
        for (var i = 0; i < mrg_class.my_string.length; i++) {

            context.font = "20px Consolas";
            context.fillStyle = 'white';
            context.fillText(mrg_string[i], 15 * i + 11, 20 + (30 * mrg_num_passes));
            context.fillText(mrg_class.my_string[i], 15 * i + 11, 20 + (30 * (mrg_num_passes - 1)));
            
            context.strokeStyle = 'white';
            context.beginPath();
            context.moveTo(15 * i + 9, 23 + (30 * (mrg_num_passes + 1)));
            context.lineTo(15 * i + 24, 23 + (30 * (mrg_num_passes + 1)));
            context.lineTo(15 * i + 24, 5 + (30 * (mrg_num_passes + 1)));
            context.lineTo(15 * i + 9, 5 + (30 * (mrg_num_passes + 1)));
            context.lineTo(15 * i + 9, 23 + (30 * (mrg_num_passes + 1)));
            context.stroke();
            
            context.strokeStyle = 'white';
            context.beginPath();
            context.moveTo(15 * i + 9, 23 + (30 * (mrg_num_passes)));
            context.lineTo(15 * i + 24, 23 + (30 * (mrg_num_passes )));
            context.lineTo(15 * i + 24, 5 + (30 * (mrg_num_passes)));
            context.lineTo(15 * i + 9, 5 + (30 * (mrg_num_passes)));
            context.lineTo(15 * i + 9, 23 + (30 * (mrg_num_passes)));
            context.stroke();

            context.strokeStyle = 'white';
            context.beginPath();
            context.moveTo(15 * i + 9, 23 + (30 * (mrg_num_passes - 1)));
            context.lineTo(15 * i + 24, 23 + (30 * (mrg_num_passes - 1)));
            context.lineTo(15 * i + 24, 5 + (30 * (mrg_num_passes - 1)));
            context.lineTo(15 * i + 9, 5 + (30 * (mrg_num_passes - 1)));
            context.lineTo(15 * i + 9, 23 + (30 * (mrg_num_passes - 1)));
            context.stroke();

        }
        mrg_size_new_string = 0;
    }
    else
    {
        context.font = "20px Consolas";
        context.fillStyle = 'white';
        for (var i = mrg_size_new_string; i < mrg_new_string.length; i++)
        {
            context.fillText(mrg_new_string[i], 15 * i + 11, 20 + (30 * (mrg_num_passes + 1)));
        }
        mrg_size_new_string = mrg_new_string.length - 1;

        if (mrg_switch_val_l[0] < mrg_string.length && mrg_switch_val_r[0] < mrg_string.length) {
            var temp = mrg_string.length;
            context.strokeStyle = 'white';
            context.beginPath();
            context.moveTo(15 * mrg_switch_val_l[0] + 9, 23 + (30 * mrg_num_passes));
            context.lineTo(15 * mrg_switch_val_l[0] + 24, 23 + (30 * mrg_num_passes));
            context.lineTo(15 * mrg_switch_val_l[0] + 24, 5 + (30 * mrg_num_passes));
            context.lineTo(15 * mrg_switch_val_l[0] + 9, 5 + (30 * mrg_num_passes));
            context.lineTo(15 * mrg_switch_val_l[0] + 9, 23 + (30 * mrg_num_passes));
            context.stroke();

            context.strokeStyle = 'white';
            context.beginPath();
            context.moveTo(15 * mrg_switch_val_r[0] + 9, 23 + (30 * mrg_num_passes));
            context.lineTo(15 * mrg_switch_val_r[0] + 24, 23 + (30 * mrg_num_passes));
            context.lineTo(15 * mrg_switch_val_r[0] + 24, 5 + (30 * mrg_num_passes));
            context.lineTo(15 * mrg_switch_val_r[0] + 9, 5 + (30 * mrg_num_passes));
            context.lineTo(15 * mrg_switch_val_r[0] + 9, 23 + (30 * mrg_num_passes));
            context.stroke();
        }

        context.strokeStyle = 'green';
        context.beginPath();
        context.moveTo(15 * mrg_class.first + 9, 23 + (30 * mrg_num_passes));
        context.lineTo(15 * mrg_class.first + 24, 23 + (30 * mrg_num_passes));
        context.lineTo(15 * mrg_class.first + 24, 5 + (30 * mrg_num_passes));
        context.lineTo(15 * mrg_class.first + 9, 5 + (30 * mrg_num_passes));
        context.lineTo(15 * mrg_class.first + 9, 23 + (30 * mrg_num_passes));
        context.stroke();

        context.strokeStyle = 'green';
        context.beginPath();
        context.moveTo(15 * mrg_class.second + 9, 23 + (30 * mrg_num_passes));
        context.lineTo(15 * mrg_class.second + 24, 23 + (30 * mrg_num_passes));
        context.lineTo(15 * mrg_class.second + 24, 5 + (30 * mrg_num_passes));
        context.lineTo(15 * mrg_class.second + 9, 5 + (30 * mrg_num_passes));
        context.lineTo(15 * mrg_class.second + 9, 23 + (30 * mrg_num_passes));
        context.stroke();
    }
}

function qui_mng(context, qui_class)
{
    if (qui_switch_p_flag == true)
    {
        for (var i = 0; i < qui_class.my_string.length; i++) {

            context.font = "20px Consolas";
            context.fillStyle = 'black';
            context.fillRect(15 * i + 211, 7 + (30 * qui_num_passes), 12, 14);
            context.fillStyle = 'white';
            context.fillText(qui_class.my_string[i], 15 * i + 211, 20 + (30 * qui_num_passes));
        }
        qui_switch_p_flag = false;
        context.strokeStyle = 'blue';
        context.beginPath();
        context.moveTo(15 * qui_class.curr_p + 209, 23 + (30 * qui_num_passes));
        context.lineTo(15 * qui_class.curr_p + 224, 23 + (30 * qui_num_passes));
        context.lineTo(15 * qui_class.curr_p + 224, 5 + (30 * qui_num_passes));
        context.lineTo(15 * qui_class.curr_p + 209, 5 + (30 * qui_num_passes));
        context.lineTo(15 * qui_class.curr_p + 209, 23 + (30 * qui_num_passes));
        context.stroke();

        context.strokeStyle = 'blue';
        context.beginPath();
        context.moveTo(15 * qui_class.first + 209, 23 + (30 * qui_num_passes));
        context.lineTo(15 * qui_class.first + 224, 23 + (30 * qui_num_passes));
        context.lineTo(15 * qui_class.first + 224, 5 + (30 * qui_num_passes));
        context.lineTo(15 * qui_class.first + 209, 5 + (30 * qui_num_passes));
        context.lineTo(15 * qui_class.first + 209, 23 + (30 * qui_num_passes));
        context.stroke();

        

    }
    else if (qui_switch_c_flag == true)
    {
        for (var i = 0; i < qui_class.my_string.length; i++) {

            context.font = "20px Consolas";
            context.fillStyle = 'black';
            context.fillRect(15 * i + 211, 7 + (30 * qui_num_passes), 12, 14);
            context.fillStyle = 'white';
            context.fillText(qui_class.my_string[i], 15 * i + 211, 20 + (30 * qui_num_passes));
        }
        qui_switch_c_flag = false;
        context.strokeStyle = 'blue';
        context.beginPath();
        context.moveTo(15 * qui_class.first + 209, 23 + (30 * qui_num_passes));
        context.lineTo(15 * qui_class.first + 224, 23 + (30 * qui_num_passes));
        context.lineTo(15 * qui_class.first + 224, 5 + (30 * qui_num_passes));
        context.lineTo(15 * qui_class.first + 209, 5 + (30 * qui_num_passes));
        context.lineTo(15 * qui_class.first + 209, 23 + (30 * qui_num_passes));
        context.stroke();

        context.strokeStyle = 'blue';
        context.beginPath();
        context.moveTo(15 * qui_class.second + 209, 23 + (30 * qui_num_passes));
        context.lineTo(15 * qui_class.second + 224, 23 + (30 * qui_num_passes));
        context.lineTo(15 * qui_class.second + 224, 5 + (30 * qui_num_passes));
        context.lineTo(15 * qui_class.second + 209, 5 + (30 * qui_num_passes));
        context.lineTo(15 * qui_class.second + 209, 23 + (30 * qui_num_passes));
        context.stroke();
    }
    else if (qui_new_pass == true) {
        qui_new_pass = false;
        context.fillStyle = 'black';
        context.fillRect(208, 3 + (30 * (qui_num_passes - 1)), 195, 21);
        for (var i = 0; i < qui_class.my_string.length; i++) {

            context.font = "20px Consolas";
            context.fillStyle = 'white';
            context.fillText(qui_class.my_string[i], 15 * i + 211, 20 + (30 * qui_num_passes));
            context.fillText(qui_class.my_string[i], 15 * i + 211, 20 + (30 * (qui_num_passes - 1)));
            if (qui_arr_p[i] == true || i == 0) {
                context.strokeStyle = 'yellow';
                context.beginPath();
                context.moveTo(15 * i + 209, 23 + (30 * qui_num_passes));
                context.lineTo(15 * i + 224, 23 + (30 * qui_num_passes));
                context.lineTo(15 * i + 224, 5 + (30 * qui_num_passes));
                context.lineTo(15 * i + 209, 5 + (30 * qui_num_passes));
                context.lineTo(15 * i + 209, 23 + (30 * qui_num_passes));
                context.stroke();
            }
            else {
                context.strokeStyle = 'white';
                context.beginPath();
                context.moveTo(15 * i + 209, 23 + (30 * qui_num_passes));
                context.lineTo(15 * i + 224, 23 + (30 * qui_num_passes));
                context.lineTo(15 * i + 224, 5 + (30 * qui_num_passes));
                context.lineTo(15 * i + 209, 5 + (30 * qui_num_passes));
                context.lineTo(15 * i + 209, 23 + (30 * qui_num_passes));
                context.stroke();
            }

            context.strokeStyle = 'white';
            context.beginPath();
            context.moveTo(15 * i + 209, 23 + (30 * (qui_num_passes - 1)));
            context.lineTo(15 * i + 224, 23 + (30 * (qui_num_passes - 1)));
            context.lineTo(15 * i + 224, 5 + (30 * (qui_num_passes - 1)));
            context.lineTo(15 * i + 209, 5 + (30 * (qui_num_passes - 1)));
            context.lineTo(15 * i + 209, 23 + (30 * (qui_num_passes - 1)));
            context.stroke();
            
        }
    }
    else {
        context.strokeStyle = 'white';
        context.beginPath();
        context.moveTo(15 * qui_switch_val + 209, 23 + (30 * qui_num_passes));
        context.lineTo(15 * qui_switch_val + 224, 23 + (30 * qui_num_passes));
        context.lineTo(15 * qui_switch_val + 224, 5 + (30 * qui_num_passes));
        context.lineTo(15 * qui_switch_val + 209, 5 + (30 * qui_num_passes));
        context.lineTo(15 * qui_switch_val + 209, 23 + (30 * qui_num_passes));
        context.stroke();

        context.strokeStyle = 'green';
        context.beginPath();
        context.moveTo(15 * qui_class.first + 209, 23 + (30 * qui_num_passes));
        context.lineTo(15 * qui_class.first + 224, 23 + (30 * qui_num_passes));
        context.lineTo(15 * qui_class.first + 224, 5 + (30 * qui_num_passes));
        context.lineTo(15 * qui_class.first + 209, 5 + (30 * qui_num_passes));
        context.lineTo(15 * qui_class.first + 209, 23 + (30 * qui_num_passes));
        context.stroke();

        context.strokeStyle = 'green';
        context.beginPath();
        context.moveTo(15 * qui_class.second + 209, 23 + (30 * qui_num_passes));
        context.lineTo(15 * qui_class.second + 224, 23 + (30 * qui_num_passes));
        context.lineTo(15 * qui_class.second + 224, 5 + (30 * qui_num_passes));
        context.lineTo(15 * qui_class.second + 209, 5 + (30 * qui_num_passes));
        context.lineTo(15 * qui_class.second + 209, 23 + (30 * qui_num_passes));
        context.stroke();
    }
}

function sel_mng(context, sel_class)
{
    if (sel_class.found_val == true)
    {
        var i;
        for (i = 0; i < sel_class.my_string.length; i++) {
            context.font = "20px Consolas";
            context.fillStyle = 'white';
            context.fillText(sel_class.my_string[i], 15 * i + 411, 20 + (30 * sel_head));

            context.strokeStyle = 'white';
            context.beginPath();
            context.moveTo(15 * i + 409, 23 + (30 * sel_head));
            context.lineTo(15 * i + 424, 23 + (30 * sel_head));
            context.lineTo(15 * i + 424, 5 + (30 * sel_head));
            context.lineTo(15 * i + 409, 5 + (30 * sel_head));
            context.lineTo(15 * i + 409, 23 + (30 * sel_head));
            context.stroke();

            context.fillStyle = 'black';
            context.beginPath();
            context.moveTo(15 * i + 409, 23 + (30 * (sel_head - 1)));
            context.lineTo(15 * i + 424, 23 + (30 * (sel_head - 1)));
            context.lineTo(15 * i + 424, 5 + (30 * (sel_head - 1)));
            context.lineTo(15 * i + 409, 5 + (30 * (sel_head - 1)));
            context.lineTo(15 * i + 409, 23 + (30 * (sel_head - 1)));
            context.stroke();

            context.fillStyle = 'white';
            context.beginPath();
            context.moveTo(15 * i + 409, 23 + (30 * (sel_head - 1)));
            context.lineTo(15 * i + 424, 23 + (30 * (sel_head - 1)));
            context.lineTo(15 * i + 424, 5 + (30 * (sel_head - 1)));
            context.lineTo(15 * i + 409, 5 + (30 * (sel_head - 1)));
            context.lineTo(15 * i + 409, 23 + (30 * (sel_head - 1)));
            context.stroke();
        }

            context.strokeStyle = 'green';
            context.beginPath();
            context.moveTo(15 * sel_class.first + 409, 23 + (30 * sel_head));
            context.lineTo(15 * sel_class.first + 424, 23 + (30 * sel_head));
            context.lineTo(15 * sel_class.first + 424, 5 + (30 * sel_head));
            context.lineTo(15 * sel_class.first + 409, 5 + (30 * sel_head));
            context.lineTo(15 * sel_class.first + 409, 23 + (30 * sel_head));
            context.stroke();

            context.beginPath();
            context.moveTo(15 * sel_class.second + 409, 23 + (30 * sel_head));
            context.lineTo(15 * sel_class.second + 424, 23 + (30 * sel_head));
            context.lineTo(15 * sel_class.second + 424, 5 + (30 * sel_head));
            context.lineTo(15 * sel_class.second + 409, 5 + (30 * sel_head));
            context.lineTo(15 * sel_class.second + 409, 23 + (30 * sel_head));
            context.stroke();
        //}
    }
    else
    {
        context.strokeStyle = 'white';
        context.beginPath();
        context.moveTo(15 * sel_class.switch_val + 409, 23 + (30 * sel_head));
        context.lineTo(15 * sel_class.switch_val + 424, 23 + (30 * sel_head));
        context.lineTo(15 * sel_class.switch_val + 424, 5 + (30 * sel_head));
        context.lineTo(15 * sel_class.switch_val + 409, 5 + (30 * sel_head));
        context.lineTo(15 * sel_class.switch_val + 409, 23 + (30 * sel_head));
        context.stroke();

        context.strokeStyle = 'green';
        context.beginPath();
        context.moveTo(15 * sel_class.first + 409, 23 + (30 * sel_head));
        context.lineTo(15 * sel_class.first + 424, 23 + (30 * sel_head));
        context.lineTo(15 * sel_class.first + 424, 5 + (30 * sel_head));
        context.lineTo(15 * sel_class.first + 409, 5 + (30 * sel_head));
        context.lineTo(15 * sel_class.first + 409, 23 + (30 * sel_head));
        context.stroke();

        context.strokeStyle = 'green';
        context.beginPath();
        context.moveTo(15 * sel_class.second + 409, 23 + (30 * sel_head));
        context.lineTo(15 * sel_class.second + 424, 23 + (30 * sel_head));
        context.lineTo(15 * sel_class.second + 424, 5 + (30 * sel_head));
        context.lineTo(15 * sel_class.second + 409, 5 + (30 * sel_head));
        context.lineTo(15 * sel_class.second + 409, 23 + (30 * sel_head));
        context.stroke();
    }

}

function mrg_mng2(context, mrg_class)
{
    mrg_new_pass = false;
        context.fillStyle = 'black';
        context.fillRect(8, 3 + (30 * (mrg_num_passes)), 190, 21);
        context.fillRect(8, 3 + (30 * (mrg_num_passes - 1)), 190, 21);
        for (var i = 0; i < mrg_class.my_string.length; i++) {

            context.font = "20px Consolas";
            context.fillStyle = 'white';
            context.fillText(mrg_string[i], 15 * i + 11, 20 + (30 * (mrg_num_passes)));
            context.fillText(mrg_class.my_string[i], 15 * i + 11, 20 + (30 * (mrg_num_passes - 1)));

            context.strokeStyle = 'white';
            context.beginPath();
            context.moveTo(15 * i + 9, 23 + (30 * (mrg_num_passes)));
            context.lineTo(15 * i + 24, 23 + (30 * (mrg_num_passes)));
            context.lineTo(15 * i + 24, 5 + (30 * (mrg_num_passes)));
            context.lineTo(15 * i + 9, 5 + (30 * (mrg_num_passes)));
            context.lineTo(15 * i + 9, 23 + (30 * (mrg_num_passes)));
            context.stroke();

            context.strokeStyle = 'white';
            context.beginPath();
            context.moveTo(15 * i + 9, 23 + (30 * (mrg_num_passes - 1)));
            context.lineTo(15 * i + 24, 23 + (30 * (mrg_num_passes - 1)));
            context.lineTo(15 * i + 24, 5 + (30 * (mrg_num_passes - 1)));
            context.lineTo(15 * i + 9, 5 + (30 * (mrg_num_passes - 1)));
            context.lineTo(15 * i + 9, 23 + (30 * (mrg_num_passes - 1)));
            context.stroke();
        }
        mrg_size_new_string = 0;
}

function qui_mng2(context, qui_class)
{
    context.fillStyle = 'black';
    context.fillRect(208, 3 + (30 * (qui_num_passes - 1)), 195, 21);
    for (var i = 0; i < qui_class.my_string.length; i++) {

        context.font = "20px Consolas";
        context.fillStyle = 'white';
        context.fillText(qui_class.my_string[i], 15 * i + 211, 20 + (30 * qui_num_passes));
        context.fillText(qui_class.my_string[i], 15 * i + 211, 20 + (30 * (qui_num_passes - 1)));
        if (qui_arr_p[i] == true || i == 0) {
            context.strokeStyle = 'yellow';
            context.beginPath();
            context.moveTo(15 * i + 209, 23 + (30 * qui_num_passes));
            context.lineTo(15 * i + 224, 23 + (30 * qui_num_passes));
            context.lineTo(15 * i + 224, 5 + (30 * qui_num_passes));
            context.lineTo(15 * i + 209, 5 + (30 * qui_num_passes));
            context.lineTo(15 * i + 209, 23 + (30 * qui_num_passes));
            context.stroke();
        }
        else {
            context.strokeStyle = 'white';
            context.beginPath();
            context.moveTo(15 * i + 209, 23 + (30 * qui_num_passes));
            context.lineTo(15 * i + 224, 23 + (30 * qui_num_passes));
            context.lineTo(15 * i + 224, 5 + (30 * qui_num_passes));
            context.lineTo(15 * i + 209, 5 + (30 * qui_num_passes));
            context.lineTo(15 * i + 209, 23 + (30 * qui_num_passes));
            context.stroke();
        }

        context.strokeStyle = 'white';
        context.beginPath();
        context.moveTo(15 * i + 209, 23 + (30 * (qui_num_passes - 1)));
        context.lineTo(15 * i + 224, 23 + (30 * (qui_num_passes - 1)));
        context.lineTo(15 * i + 224, 5 + (30 * (qui_num_passes - 1)));
        context.lineTo(15 * i + 209, 5 + (30 * (qui_num_passes - 1)));
        context.lineTo(15 * i + 209, 23 + (30 * (qui_num_passes - 1)));
        context.stroke();
    }
}

function sel_mng2(context, sel_class)
{
    var i;
    for (i = 0; i < sel_class.my_string.length; i++) {
        context.font = "20px Consolas";
        context.fillStyle = 'white';

        context.fillStyle = 'black';
        context.beginPath();
        context.moveTo(15 * i + 409, 23 + (30 * (sel_head - 1)));
        context.lineTo(15 * i + 424, 23 + (30 * (sel_head - 1)));
        context.lineTo(15 * i + 424, 5 + (30 * (sel_head - 1)));
        context.lineTo(15 * i + 409, 5 + (30 * (sel_head - 1)));
        context.lineTo(15 * i + 409, 23 + (30 * (sel_head - 1)));
        context.stroke();

        context.fillStyle = 'white';
        context.beginPath();
        context.moveTo(15 * i + 409, 23 + (30 * (sel_head - 1)));
        context.lineTo(15 * i + 424, 23 + (30 * (sel_head - 1)));
        context.lineTo(15 * i + 424, 5 + (30 * (sel_head - 1)));
        context.lineTo(15 * i + 409, 5 + (30 * (sel_head - 1)));
        context.lineTo(15 * i + 409, 23 + (30 * (sel_head - 1)));
        context.stroke();
    }
}